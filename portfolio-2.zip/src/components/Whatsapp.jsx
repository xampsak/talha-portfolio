import React from 'react'
import red from '/whatsapp.png'

function Whatsapp() {
  return (
    <div>
        <div>
            <img  src={red} alt="img" />
        
        </div>
      
    </div>
  )
}

export default Whatsapp
